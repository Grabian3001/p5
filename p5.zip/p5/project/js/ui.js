function drawWeaponSelectionUI() {
    let squareSize = 50; // Size of the weapon selection squares
    let padding = 10; // Padding between squares

    noStroke();
  
    // Coordinates for the first square
    let x1 = padding;
    let y1 = height - squareSize - padding;
  
    // Coordinates for the second square
    let x2 = x1 + squareSize + padding;
    let y2 = y1;
  
    // Draw the first square
    if (currentWeapon === 1) {
      fill(255, 255, 0); // Yellow for selected
    } else {
      fill(255); // White for unselected
    }
    rect(x1, y1, squareSize, squareSize);
    fill(0); // Black text
    textAlign(CENTER, CENTER);
    textSize(32); // Text size
    text("1", x1 + squareSize / 2, y1 + squareSize / 2);
  
    // Draw the second square
    if (currentWeapon === 2) {
      fill(255, 255, 0); // Yellow for selected
    } else {
      fill(255); // White for unselected
    }
    rect(x2, y2, squareSize, squareSize);
    fill(0); // Black text
    textAlign(CENTER, CENTER);
    textSize(32); // Text size
    text("2", x2 + squareSize / 2, y2 + squareSize / 2);
}

let currentFilledWidth = 0; // Initialize outside the function to maintain state

function drawAmmoBar() {
  const barWidth = 272 / 2; // Width of the ammo bar
  const barHeight = 128 / 2; // Height of the ammo bar
  const barX = 10; // X position of the ammo bar, near the top left corner
  const barY = 10; // Y position of the ammo bar, near the top left corner
  const offset = 8; // Offset to shift the filled part to the right
  const numSegments = 20; // Number of segments in the ammo bar

  noStroke();

  // Draw the base layer of the ammo bar (background layer)
  fill(50); // Dark grey color for the base layer
  rect(barX + offset, barY, barWidth - 2 * offset, barHeight);

  // Calculate the target width of the filled part based on the current ammo
  const targetFilledWidth = (totalAmmo / maxAmmo) * (barWidth - 2 * offset);

  // Animate towards the target width
  if (currentFilledWidth < targetFilledWidth) {
    currentFilledWidth += (targetFilledWidth - currentFilledWidth) * 0.1; // Speed of animation
  } else if (currentFilledWidth > targetFilledWidth) {
    currentFilledWidth -= (currentFilledWidth - targetFilledWidth) * 0.1; // Speed of animation
  }

  // Draw the filled part of the ammo bar
  fill(0, 255, 255); // Cyan color for the filled part
  rect(barX + offset, barY, currentFilledWidth, barHeight);

  // Draw segments
  stroke(0, 0, 0); // Darker shade for the segments
  strokeWeight(2);
  for (let i = 1; i < numSegments; i++) {
    let segmentX = barX + offset + (i * (barWidth - 2 * offset) / numSegments);
    if (segmentX < barX + offset + currentFilledWidth) {
      line(segmentX, barY + 2, segmentX, barY + barHeight - 2);
    }
  }

  noStroke(); // Reset stroke settings

  // Draw the PNG image as the overlay of the ammo bar
  image(ammoBarBackground, barX, barY, barWidth, barHeight);
}

function drawUI() {
  fill(255); // White color for text
  noStroke();
  textSize(20); // Set the text size
  textAlign(CENTER, TOP); // Center align text horizontally

  // Get the center x-coordinate of the canvas
  let centerX = width / 2;

  // Display the current wave number at the center
  text(`Wave: ${currentWave}`, centerX, 10);

  // Display the number of enemies left, slightly below the wave number
  text(`Enemies Left: ${enemies.length}`, centerX, 35);
}

function drawHealthBar() {
    const barWidth = 272 / 2; // Width of the health bar, matching the ammo bar
    const barHeight = 128 / 2; // Height of the health bar, matching the ammo bar
    const barX = width - barWidth - 10; // X position of the health bar, in the top right corner
    const barY = 10; // Y position of the health bar, near the top of the screen
    const offset = 8; // Offset to shift the filled part to the right, matching the ammo bar

    noStroke();

    // Draw the base layer of the health bar (background layer)
    fill(50); // Dark grey color for the base layer
    rect(barX + offset, barY, barWidth - 2 * offset, barHeight);

    // Calculate the width of the filled part based on current health
    const healthWidth = (playerHealth / 100) * (barWidth - 2 * offset);
    fill(255, 0, 0); // Red color for the health fill
    rect(barX + offset, barY, healthWidth, barHeight);

    // Draw segments
    stroke(0, 0, 0); // Darker shade for the segments
    strokeWeight(2);
    for (let i = 1; i < 20; i++) { // Assuming 20 segments like the ammo bar
        let segmentX = barX + offset + (i * (barWidth - 2 * offset) / 20);
        if (segmentX < barX + offset + healthWidth) {
            line(segmentX, barY + 2, segmentX, barY + barHeight - 2);
        }
    }

    noStroke(); // Reset stroke settings

    // Draw the PNG image as the overlay of the health bar
    image(ammoBarBackground, barX, barY, barWidth, barHeight);
}

