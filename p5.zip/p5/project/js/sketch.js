let tileSize = 50;
let rows = 10;
let cols = 10;
let character = { x: 4, y: 4 }; // Character's position in grid coordinates
let terrain = []; // 2D array to store terrain data
let enemies = []; // Array to hold enemies
let bullets = []; // Array to hold bullets
let ammoDrops = []; // Array to hold ammo drops
let characterSpeed = 0.1; // Speed of character movement
let bulletSpeed = 0.3; // Speed of bullet movement
let currentWeapon = 1; // 1 for current firing mode, 2 for shotgun
let shotgunBullets = 5; // Number of bullets fired by the shotgun
let meleeRange = 1.5; // Melee attack range in terms of grid cells
let showMeleeRange = false; // Variable to control display of melee range
let totalAmmo = 100; // Total ammo available for use by any weapon
let maxAmmo = 100; // Maximum ammo player can carry
let ammoDropChance = 0.5; // 50% chance to drop ammo
let playerHealth = 100; // Initialize player health to 100
let playerHit = false; // Flag to indicate player was hit

let ammoImage;  
let ammoBarBackground;
let walkableTileTextures = [];
let nonWalkableTileTexture;

let currentWave = 1;

// Animation frames for soldier enemy type
let soldierWalkingFrame1;
let soldierWalkingFrame2;
let soldierAnimationCounter = 0;

// Animation frames for soldier enemy type
let toughSoldierWalkingFrame1;
let toughSoldierWalkingFrame2;
let toughSoldierAnimationCounter = 0;

// Animation frames for soldier enemy type
let eliteSoldierWalkingFrame1;
let eliteSoldierWalkingFrame2;
let eliteSoldierAnimationCounter = 0;

let weaponImages = [];
let currentWeaponIndex = 0; // Index to track the currently equipped weapon

let playerWalkingFrame1;
let playerWalkingFrame2;
let playerAnimationCounter = 0;

function preload() {
  ammoImage = loadImage('./assets/water.png'); // Make sure to provide the correct path to your image file
  ammoBarBackground = loadImage('./assets/ammo_bar_outline.png'); // New image
  walkableTileTextures.push(loadImage('./assets/grass_1.png'));
  walkableTileTextures.push(loadImage('./assets/grass_2.png'));
  walkableTileTextures.push(loadImage('./assets/grass_3.png'));
  walkableTileTextures.push(loadImage('./assets/grass_4.png'));
  nonWalkableTileTexture = loadImage('./assets/wall.png');

  soldierWalkingFrame1 = loadImage('./assets/soldier/walk1.png');
  soldierWalkingFrame2 = loadImage('./assets/soldier/walk2.png');

  toughSoldierWalkingFrame1 = loadImage('./assets/soldier/t_walk1.png');
  toughSoldierWalkingFrame2 = loadImage('./assets/soldier/t_walk2.png');

  eliteSoldierWalkingFrame1 = loadImage('./assets/soldier/e_walk1.png');
  eliteSoldierWalkingFrame2 = loadImage('./assets/soldier/e_walk2.png');

  playerWalkingFrame1 = loadImage('./assets/player/pope_1.png');
  playerWalkingFrame2 = loadImage('./assets/player/pope_2.png');

  weaponImages.push(loadImage('./assets/weapons/water_pistol.png')); // Path to the first weapon image
  weaponImages.push(loadImage('./assets/weapons/kropidlo.png')); // Path to the second weapon image
}

let width = 800; // Width of canvas
let height = 600; // Height of canvas

// Define chunk size and a map to store chunks
const CHUNK_SIZE = 10;
let chunks = {};

function getChunkCoord(x, y) {
  let chunkX = floor(x / CHUNK_SIZE);
  let chunkY = floor(y / CHUNK_SIZE);
  return { chunkX, chunkY };
}

function generateChunk(chunkX, chunkY) {
  if (!chunks[`${chunkX},${chunkY}`]) {
    let terrainChunk = [];
    for (let i = 0; i < CHUNK_SIZE; i++) {
      terrainChunk[i] = [];
      for (let j = 0; j < CHUNK_SIZE; j++) {
        // Assign a random texture index to each walkable tile
        terrainChunk[i][j] = {
          type: random() > 0.1 ? 1 : 0,
          textureIndex: floor(random(walkableTileTextures.length))
        };
      }
    }
    chunks[`${chunkX},${chunkY}`] = terrainChunk;
  }
}

function ensureChunksAroundPlayer() {
  let { chunkX, chunkY } = getChunkCoord(character.x, character.y);
  for (let dx = -1; dx <= 1; dx++) {
    for (let dy = -1; dy <= 1; dy++) {
      generateChunk(chunkX + dx, chunkY + dy);
    }
  }
}

function setup() {
  createCanvas(width, height);
  frameRate(30);
  //initTerrain();
  spawnEnemies(1, currentWave); // Spawn 5 enemies initially
}

function draw() {
  background(30); // Clear the canvas

  if (playerHealth <= 0) {
      drawGameOverScreen();
  } else {
      ensureChunksAroundPlayer();
      handleMovement();
      updateBullets();
      updateGame();

      // Bottom Layer: Draw walkable tiles
      drawIsometricGrid();

      // Draw the sides of non-walkable tiles here, before drawing characters and enemies
      drawNonWalkableTileSides();

      // Mid Layer: Draw game elements like characters and enemies
      drawEnemies();
      drawBullets();
      drawCharacter();

      // Highest Layer: Draw the top of non-walkable tiles
      drawNonWalkableTileTops();

      // Top Layer: Draw UI elements
      drawWeaponSelectionUI();
      drawMeleeRange();
      drawEnemyIndicator();
      drawAmmoDrops();
      drawAmmoBar();
      drawHealthBar();
      drawUI();
  }
}


function drawGameOverScreen() {
    fill(0); // Black background for the game over screen
    rect(0, 0, width, height); // Cover the entire canvas
    fill(255, 0, 0); // Red text for "GAME OVER"
    textSize(32);
    textAlign(CENTER, CENTER);
    text("GAME OVER", width / 2, height / 2);
    textSize(24);
    fill(255); // White text for "Press LMB to retry"
    text("Press LMB to retry", width / 2, height / 2 + 40);
}

function resetGame() {
    playerHealth = 100; // Reset health
    enemies = []; // Clear enemies
    bullets = []; // Clear bullets
    ammoDrops = []; // Clear ammo drops
    currentWave = 1; // Reset to first wave
    setup(); // Reinitialize the game setup
}

function updateGame() {
    if (enemies.length === 0) {
        spawnEnemies(5 + currentWave, currentWave);
        currentWave++;
    } else {
        moveEnemiesTowardsPlayer();
    }
}

let lastCharacterPosition = { x: character.x, y: character.y }; // Initialize with the starting position

function drawCharacter() {
  const screenX = width / 2;
  const screenY = height / 3;

  noStroke();
  
  // Draw shadow
  fill(0, 0, 0, 100); // Semi-transparent black
  ellipse(screenX, screenY + tileSize * 0.5, tileSize * 0.5, tileSize * 0.25);

  // Draw equipped weapon
  drawWeapon(screenX, screenY);

  // Player walking animation
  let playerImage = playerWalkingFrame1; // Default frame
  if (character.x !== lastCharacterPosition.x || character.y !== lastCharacterPosition.y) {
    if (frameCount % 30 < 15) {
      playerImage = playerWalkingFrame1;
    } else {
      playerImage = playerWalkingFrame2;
    }
    lastCharacterPosition.x = character.x;
    lastCharacterPosition.y = character.y;
  }

  // Apply red tint if the player was hit
  if (playerHit) {
    tint(255, 0, 0); // Apply red color
  }

  image(playerImage, screenX - tileSize / 2, screenY - tileSize / 2, tileSize, tileSize);

  // Reset tint to default
  noTint();

  // Reset player hit flag after drawing
  playerHit = false;
}

function drawWeapon(x, y) {
  const weaponDistance = 40; // Distance from the center of the player
  const angle = atan2(mouseY - y, mouseX - x); // Angle towards the mouse cursor
  const weaponOffsetX = weaponDistance * cos(angle); // Calculate the X offset based on the angle
  const weaponOffsetY = weaponDistance * sin(angle); // Calculate the Y offset based on the angle

  push();
  translate(x + weaponOffsetX, y + weaponOffsetY);
  rotate(angle);

  // Check if the weapon is on the left side of the player
  if (weaponOffsetX < 0) {
      scale(1, -1); // Flip the image horizontally
  }

  imageMode(CENTER);
  image(weaponImages[currentWeaponIndex], 0, 0, tileSize * 0.75, tileSize * 0.75); // Adjust size as needed
  pop();
}

function meleeAttack() {
  enemies = enemies.filter(enemy => {
    let distance = dist(character.x, character.y, enemy.x, enemy.y);
    if (distance <= meleeRange) {
      if (random() < ammoDropChance) { // Check if ammo should drop
        ammoDrops.push({ x: enemy.x, y: enemy.y, amount: 5 });
      }
      return false; // Remove enemy
    }
    return true;
  });
}

function drawMeleeRange() {
  if (showMeleeRange) {
    let screenX = width / 2;
    let screenY = height / 3;
    noFill();
    stroke(255, 0, 0); // Red color for melee range
    ellipse(screenX, screenY, meleeRange * tileSize, meleeRange * tileSize);
  }
}

function drawAmmoDrops() {
  let offsetX = width / 2 - (character.x - character.y) * tileSize;
  let offsetY = height / 3 - (character.x + character.y) * tileSize / 2;

  for (let drop of ammoDrops) {
    const isoX = (drop.x - drop.y) * tileSize;
    const isoY = (drop.x + drop.y) * tileSize / 2;
    const screenX = offsetX + isoX;
    const screenY = offsetY + isoY;

    // Draw shadow with cyan border
    stroke(0, 255, 255); // Cyan border color
    fill(0, 0, 0, 100); // Semi-transparent black for shadow
    ellipse(screenX, screenY + tileSize * 0.15, tileSize * 0.3, tileSize * 0.15);

    // Calculate pulsing effect
    let pulse = sin(millis() / 500) * 0.5 + 1; // Adjust the speed and intensity of the pulse
    let pulsingSize = tileSize * 0.3 * pulse;

    // Draw the ammo image with pulsing effect
    noStroke(); // Disable stroke for the image
    image(ammoImage, screenX - pulsingSize / 2, screenY - pulsingSize / 2, pulsingSize, pulsingSize);
  }
}