function drawBullets() {
    let offsetX = width / 2 - (character.x - character.y) * tileSize;
    let offsetY = height / 3 - (character.x + character.y) * tileSize / 2;
    
    for (let bullet of bullets) {
        const isoX = (bullet.x - bullet.y) * tileSize;
        const isoY = (bullet.x + bullet.y) * tileSize / 2;
        const screenX = offsetX + isoX;
        const screenY = offsetY + isoY;
        
        // Determine bullet color and glow based on the source
        if (bullet.source === 'enemy') {
            fill(255, 0, 0); // Red color for enemy bullets
            stroke(255, 100, 100); // Lighter red for glow
            strokeWeight(2); // Glow effect
        } else {
            let colorValue = floor(random(255));
            fill(colorValue, colorValue, 255); // Random shades of blue for other bullets
            noStroke(); // No glow for other bullets
        }

        ellipse(screenX, screenY, tileSize * 0.2, tileSize * 0.2);
    }
}

function updateBullets() {
    bullets = bullets.map(bullet => {
        // Move bullet
        bullet.x += bullet.vx * bulletSpeed;
        bullet.y += bullet.vy * bulletSpeed;
        
        // Ensure the chunk for the new bullet position is generated
        let newChunkCoords = getChunkCoord(bullet.x, bullet.y);
        generateChunk(newChunkCoords.chunkX, newChunkCoords.chunkY);

        return bullet;
    }).filter(bullet => {
        let bulletRemoved = false;

        let chunkCoords = getChunkCoord(bullet.x, bullet.y);
        let localX = Math.floor(bullet.x % CHUNK_SIZE);
        let localY = Math.floor(bullet.y % CHUNK_SIZE);
        if (localX < 0) localX += CHUNK_SIZE;
        if (localY < 0) localY += CHUNK_SIZE;

        let chunkKey = `${chunkCoords.chunkX},${chunkCoords.chunkY}`;
        if (chunks[chunkKey] && chunks[chunkKey][localX][localY].type === 0) {
            bulletRemoved = true;
        }

        // Check collision with player
        let distanceToPlayer = dist(bullet.x, bullet.y, character.x, character.y);
        if (distanceToPlayer < 0.5 && bullet.source === 'enemy') {
            playerHealth -= 10; // Damage the player
            playerHit = true; // Set the hit flag
            setTimeout(() => { playerHit = false; }, 200); // Reset flag after 200 ms
            bulletRemoved = true;
        }

        for (let i = 0; i < enemies.length; i++) {
            if (bullet.source === 'enemy' && bullet.x === enemies[i].x && bullet.y === enemies[i].y) {
                continue; // Skip collision check if the bullet was fired by this enemy
            }
            let distance = dist(bullet.x, bullet.y, enemies[i].x, enemies[i].y);
            if (distance < 0.5 && bullet.source !== 'enemy') {
                enemies[i].health -= 1;
                if (enemies[i].health <= 0) {
                    if (random() < ammoDropChance) {
                        ammoDrops.push({ x: enemies[i].x, y: enemies[i].y, amount: 5 });
                    }
                    enemies.splice(i, 1);
                }
                bulletRemoved = true;
                break;
            }
        }
        return !bulletRemoved;
    });
}

function enemyShoot(enemy) {
    let directionX = character.x - enemy.x;
    let directionY = character.y - enemy.y;
    let magnitude = Math.sqrt(directionX * directionX + directionY * directionY);

    // Normalize the direction
    directionX /= magnitude;
    directionY /= magnitude;

    // Create a bullet moving towards the player with a source marker
    bullets.push({
        x: enemy.x,
        y: enemy.y,
        vx: directionX * 0.5,
        vy: directionY * 0.5,
        source: 'enemy'  // Mark the bullet's source as 'enemy'
    });
}