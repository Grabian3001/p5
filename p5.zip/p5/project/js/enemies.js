function createEnemy(x, y, type) {
    let enemy = {
        x: x,
        y: y,
        type: type,
        health: 1 // Default health
    };

    switch (type) {
        case 'tough':
            enemy.health = 2; // Tough enemies require 2 hits
            break;
        case 'elite':
            enemy.health = 5; // Elite enemies require 5 hits
            break;
    }

    return enemy;
}

function spawnEnemies(count, waveNumber) {
    let { chunkX, chunkY } = getChunkCoord(character.x, character.y);
    let spawnChunkRange = 0; // Adjust this if you want enemies to spawn further from the player

    // Base chance for a tough enemy to spawn
    let baseToughEnemyChance = 0.1; // 10% at wave 1
    // Increase chance by 2% per wave
    let increasePerWave = 0.02;

    for (let i = 0; i < count; i++) {
        let targetChunkX = chunkX + floor(random(-spawnChunkRange, spawnChunkRange + 1));
        let targetChunkY = chunkY + floor(random(-spawnChunkRange, spawnChunkRange + 1));
        generateChunk(targetChunkX, targetChunkY);

        let localX = floor(random(CHUNK_SIZE));
        let localY = floor(random(CHUNK_SIZE));
        let globalX = targetChunkX * CHUNK_SIZE + localX;
        let globalY = targetChunkY * CHUNK_SIZE + localY;

        if (chunks[`${targetChunkX},${targetChunkY}`][localX][localY].type === 1) {
            let toughEnemyChance = baseToughEnemyChance + increasePerWave * (waveNumber - 1);
            toughEnemyChance = Math.min(toughEnemyChance, 0.5); // Cap the chance at 50% to avoid over-saturation

            let type = 'normal';
            // Randomly decide if this enemy is tough
            if (random() < toughEnemyChance) {
                type = 'tough';
            }

            if (waveNumber >= 10 && random() < 0.1) { // 10% chance to spawn an elite enemy from wave 10
                type = 'elite';
            }

            enemies.push(createEnemy(globalX, globalY, type));
        }
    }
}

function drawEnemies() {
    let offsetX = width / 2 - (character.x - character.y) * tileSize;
    let offsetY = height / 3 - (character.x + character.y) * tileSize / 2;
  
    for (let enemy of enemies) {
        const isoX = (enemy.x - enemy.y) * tileSize;
        const isoY = (enemy.x + enemy.y) * tileSize / 2;
        const screenX = offsetX + isoX;
        const screenY = offsetY + isoY;
  
        // Draw shadow
        fill(0, 0, 0, 100); // Semi-transparent black for the shadow
        ellipse(screenX, screenY + tileSize * 0.5, tileSize * 0.5, tileSize * 0.25);
  
  
        let enemyImage;
        if (enemy.type === 'normal') {
            // Switch between frames for the walking animation
            if (frameCount % 30 < 15) { // Change 30 to adjust speed of animation
              enemyImage = soldierWalkingFrame1;
            } else {
              enemyImage = soldierWalkingFrame2;
            }
            image(enemyImage, screenX - tileSize / 2, screenY - tileSize / 2, tileSize, tileSize);
        } else if (enemy.type === 'tough') {
            // Switch between frames for the walking animation
            if (frameCount % 30 < 15) { // Change 30 to adjust speed of animation
              enemyImage = toughSoldierWalkingFrame1;
            } else {
              enemyImage = toughSoldierWalkingFrame2;
            }
            image(enemyImage, screenX - tileSize / 2, screenY - tileSize / 2, tileSize, tileSize);
        } else if (enemy.type === 'elite') {
            // Switch between frames for the walking animation
            if (frameCount % 30 < 15) { // Change 30 to adjust speed of animation
              enemyImage = eliteSoldierWalkingFrame1;
            } else {
              enemyImage = eliteSoldierWalkingFrame2;
            }
            image(enemyImage, screenX - tileSize / 2, screenY - tileSize / 2, tileSize, tileSize);
        }
    }
}

function moveEnemiesTowardsPlayer() {
    enemies.forEach(enemy => {
        let directionX = character.x - enemy.x;
        let directionY = character.y - enemy.y;
        let magnitude = Math.sqrt(directionX * directionX + directionY * directionY);
        
        // Normalize the direction
        directionX /= magnitude;
        directionY /= magnitude;
        
        // Move enemy towards the player
        enemy.x += directionX * 0.05; // Adjust speed as necessary
        enemy.y += directionY * 0.05; // Adjust speed as necessary
        
        // Ensure the enemy stays within the bounds and on valid terrain
        let newChunkCoords = getChunkCoord(enemy.x, enemy.y);
        let localX = Math.floor(enemy.x % CHUNK_SIZE);
        let localY = Math.floor(enemy.y % CHUNK_SIZE);
        if (localX < 0) localX += CHUNK_SIZE;
        if (localY < 0) localY += CHUNK_SIZE;
        
        // Check if the new position is within valid terrain
        let chunkKey = `${newChunkCoords.chunkX},${newChunkCoords.chunkY}`;
        if (!chunks[chunkKey] || chunks[chunkKey][localX][localY].type !== 1) {
        enemy.x -= directionX * 0.05; // Revert if moving into invalid terrain
        enemy.y -= directionY * 0.05; // Revert if moving into invalid terrain
        }
        if (random() < 0.005) { // Example: 10% chance to shoot each frame
            enemyShoot(enemy);
        }
    });
}

function findClosestEnemy() {
    let closestEnemy = null;
    let minDistance = Infinity;
    for (let enemy of enemies) {
        let distance = dist(character.x, character.y, enemy.x, enemy.y);
        if (distance < minDistance) {
        minDistance = distance;
        closestEnemy = enemy;
        }
    }
    return closestEnemy;
}

function drawEnemyIndicator() {
    let closestEnemy = findClosestEnemy();
    if (closestEnemy) {
        let offsetX = width / 2 - (character.x - character.y) * tileSize;
        let offsetY = height / 3 - (character.x + character.y) * tileSize / 2;

        let enemyScreenX = offsetX + (closestEnemy.x - closestEnemy.y) * tileSize;
        let enemyScreenY = offsetY + (closestEnemy.x + closestEnemy.y) * tileSize / 2;

        let characterScreenX = width / 2;
        let characterScreenY = height / 3;

        stroke(255, 0, 0); // Red color for the indicator
        line(characterScreenX, characterScreenY, enemyScreenX, enemyScreenY);
    }
}
