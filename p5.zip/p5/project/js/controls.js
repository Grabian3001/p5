function handleMovement() {
    let moveX = 0;
    let moveY = 0;

    if (keyIsDown(87)) { // W key for North-West
        moveX -= characterSpeed;
        moveY -= characterSpeed;
    }
    if (keyIsDown(83)) { // S key for South-East
        moveX += characterSpeed;
        moveY += characterSpeed;
    }
    if (keyIsDown(65)) { // A key for South-West
        moveX -= characterSpeed;
        moveY += characterSpeed;
    }
    if (keyIsDown(68)) { // D key for North-East
        moveX += characterSpeed;
        moveY -= characterSpeed;
    }

    // Normalize diagonal speed
    if (moveX !== 0 && moveY !== 0) {
        moveX /= Math.sqrt(2);
        moveY /= Math.sqrt(2);
    }

    let newX = character.x + moveX;
    let newY = character.y + moveY;

    // Convert character position to chunk coordinates and local tile coordinates
    let newChunkCoords = getChunkCoord(newX, newY);
    let localX = floor(newX % CHUNK_SIZE);
    let localY = floor(newY % CHUNK_SIZE);
    if (localX < 0) localX += CHUNK_SIZE;
    if (localY < 0) localY += CHUNK_SIZE;

    // Check if the new position is within valid terrain
    let chunkKey = `${newChunkCoords.chunkX},${newChunkCoords.chunkY}`;
    if (chunks[chunkKey] && chunks[chunkKey][localX][localY].type === 1) {
        character.x = newX;
        character.y = newY;
    }
    
    // Attack with spacebar
    if (keyIsDown(32)) { // Spacebar to attack
        meleeAttack();
        showMeleeRange = true; // Show melee range when attacking
    } else {
        showMeleeRange = false;
    }

    // Check for ammo pickup
    ammoDrops = ammoDrops.filter(drop => {
        let distance = dist(character.x, character.y, drop.x, drop.y);
        if (distance < 0.5 && totalAmmo < maxAmmo) { // Adjust pickup range as needed and check if ammo is not full
        let possibleNewAmmo = totalAmmo + drop.amount;
        if (possibleNewAmmo > maxAmmo) {
            totalAmmo = maxAmmo; // Set to max if exceeding
        } else {
            totalAmmo = possibleNewAmmo; // Otherwise, add normally
        }
        return false; // Remove drop from array
        }
        return true; // Keep the drop if not picked up
    });
}

function keyPressed() {
    if (key === '1') {
      currentWeapon = 1;
      currentWeaponIndex = 0;
    } else if (key === '2') {
      currentWeapon = 2;
      currentWeaponIndex = 1;
    }
}

function mousePressed() {
    if (currentWeapon === 1) {
        if (totalAmmo > 0) {
        let offsetX = width / 2 - (character.x - character.y) * tileSize;
        let offsetY = height / 3 - (character.x + character.y) * tileSize / 2;
        
        let mouseIsoX = (mouseX - offsetX) / tileSize;
        let mouseIsoY = (mouseY - offsetY) / (tileSize / 2);
        
        let targetX = (mouseIsoX + mouseIsoY) / 2;
        let targetY = (mouseIsoY - mouseIsoX) / 2;
        
        let dirX = targetX - character.x;
        let dirY = targetY - character.y;
        let magnitude = sqrt(dirX * dirX + dirY * dirY);
        
        dirX /= magnitude;
        dirY /= magnitude;
        
        bullets.push({ x: character.x, y: character.y, vx: dirX, vy: dirY });
        totalAmmo -= 1; // Decrease ammo by 1 for weapon 1
        }
    } else if (currentWeapon === 2) {
        if (totalAmmo >= 5) { // Check if there's enough ammo for a shotgun blast
        let offsetX = width / 2 - (character.x - character.y) * tileSize;
        let offsetY = height / 3 - (character.x + character.y) * tileSize / 2;
        
        let mouseIsoX = (mouseX - offsetX) / tileSize;
        let mouseIsoY = (mouseY - offsetY) / (tileSize / 2);
        
        let targetX = (mouseIsoX + mouseIsoY) / 2;
        let targetY = (mouseIsoY - mouseIsoX) / 2;
        
        let angle = atan2(targetY - character.y, targetX - character.x);

        for (let i = 0; i < shotgunBullets; i++) {
            let adjustedAngle = angle + random(-PI / 12, PI / 12);
            let dirX = cos(adjustedAngle);
            let dirY = sin(adjustedAngle);
            bullets.push({ x: character.x, y: character.y, vx: dirX, vy: dirY });
        }
        totalAmmo -= 5; // Decrease ammo by 5 for weapon 2
        }
    }
    if (playerHealth <= 0) {
        resetGame();
    }
}
