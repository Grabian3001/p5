function initTerrain() {
    // Initialize terrain data (1 = valid surface, 0 = invalid surface)
    for (let i = 0; i < cols; i++) {
      terrain[i] = [];
      for (let j = 0; j < rows; j++) {
        if (i === 0 || j === 0 || i === cols - 1 || j === rows - 1) {
          terrain[i][j] = 0; // Border tiles are invalid surfaces
        } else {
          terrain[i][j] = 1; // Inner tiles are valid surfaces
        }
      }
    }
  }

function drawIsometricGrid() {
    let { chunkX, chunkY } = getChunkCoord(character.x, character.y);
    let visibleChunkRange = 1;
    let startX = chunkX - visibleChunkRange;
    let endX = chunkX + visibleChunkRange;
    let startY = chunkY - visibleChunkRange;
    let endY = chunkY + visibleChunkRange;

    let offsetX = width / 2 - (character.x - character.y) * tileSize;
    let offsetY = height / 3 - (character.x + character.y) * tileSize / 2;

    for (let cx = startX; cx <= endX; cx++) {
        for (let cy = startY; cy <= endY; cy++) {
            let chunkKey = `${cx},${cy}`;
            if (chunks[chunkKey]) {
                for (let i = 0; i < CHUNK_SIZE; i++) {
                    for (let j = 0; j < CHUNK_SIZE; j++) {
                        const tile = chunks[chunkKey][i][j];
                        const isoX = (cx * CHUNK_SIZE + i - cy * CHUNK_SIZE - j) * tileSize;
                        const isoY = (cx * CHUNK_SIZE + i + cy * CHUNK_SIZE + j) * tileSize / 2;
                        const screenX = offsetX + isoX;
                        const screenY = offsetY + isoY;

                        if (tile.type === 1) {
                            push(); // Save the current drawing context
                            translate(screenX, screenY);
                            applyMatrix(1, 0.5, -1, 0.5, 0, 0); // Apply matrix to skew the image for isometric view
                            image(walkableTileTextures[tile.textureIndex], 0, 0, tileSize, tileSize);
                            pop(); // Restore the original drawing context
                        }
                    }
                }
            }
        }
    }
}

function drawNonWalkableTileSides() {
    let { chunkX, chunkY } = getChunkCoord(character.x, character.y);
    let visibleChunkRange = 1;
    let startX = chunkX - visibleChunkRange;
    let endX = chunkX + visibleChunkRange;
    let startY = chunkY - visibleChunkRange;
    let endY = chunkY + visibleChunkRange;

    let offsetX = width / 2 - (character.x - character.y) * tileSize;
    let offsetY = height / 3 - (character.x + character.y) * tileSize / 2;

    for (let cx = startX; cx <= endX; cx++) {
        for (let cy = startY; cy <= endY; cy++) {
            let chunkKey = `${cx},${cy}`;
            if (chunks[chunkKey]) {
                for (let i = 0; i < CHUNK_SIZE; i++) {
                    for (let j = 0; j < CHUNK_SIZE; j++) {
                        const tile = chunks[chunkKey][i][j];
                        if (tile.type === 0) { // Only draw for non-walkable tiles
                            const isoX = (cx * CHUNK_SIZE + i - cy * CHUNK_SIZE - j) * tileSize;
                            const isoY = (cx * CHUNK_SIZE + i + cy * CHUNK_SIZE + j) * tileSize / 2;
                            const screenX = offsetX + isoX;
                            const screenY = offsetY + isoY;

                            // Draw shadows for adjacent tiles
                            drawTileShadows(cx, cy, i, j, offsetX, offsetY);
                            
                            // Draw the tile sides
                            push();
                            translate(screenX, screenY - tileSize / 2);
                            fill(100, 100, 100); // Grey color for the sides
                            beginShape();
                            vertex(-tileSize, tileSize / 2);
                            vertex(0, tileSize);
                            vertex(tileSize, tileSize / 2);
                            vertex(tileSize, tileSize);
                            vertex(0, tileSize * 1.5);
                            vertex(-tileSize, tileSize);
                            endShape(CLOSE);
                            pop();
                        }
                    }
                }
            }
        }
    }
}

function drawTileShadows(chunkX, chunkY, tileX, tileY, offsetX, offsetY) {
    let chunkKey = `${chunkX},${chunkY}`;
    let adjacentOffsets = [[-1, 0]]; // Define other offsets as needed

    adjacentOffsets.forEach(offset => {
        let adjX = tileX + offset[0];
        let adjY = tileY + offset[1];
        if (adjX >= 0 && adjX < CHUNK_SIZE && adjY >= 0 && adjY < CHUNK_SIZE && chunks[chunkKey][adjX][adjY].type === 1) {
            const adjIsoX = (chunkX * CHUNK_SIZE + adjX - chunkY * CHUNK_SIZE - adjY) * tileSize;
            const adjIsoY = (chunkX * CHUNK_SIZE + adjX + chunkY * CHUNK_SIZE + adjY) * tileSize / 2;
            const adjScreenX = offsetX + adjIsoX;
            const adjScreenY = offsetY + adjIsoY;

            push();
            translate(adjScreenX, adjScreenY);
            fill(0, 0, 0, 100); // Semi-transparent black for shadow
            beginShape();
            vertex(-tileSize, tileSize / 2);
            vertex(0, tileSize);
            vertex(tileSize, tileSize / 2);
            vertex(0, 0);
            endShape(CLOSE);
            pop();
        }
    });
}

function drawNonWalkableTileTops() {
    let { chunkX, chunkY } = getChunkCoord(character.x, character.y);
    let visibleChunkRange = 1;
    let startX = chunkX - visibleChunkRange;
    let endX = chunkX + visibleChunkRange;
    let startY = chunkY - visibleChunkRange;
    let endY = chunkY + visibleChunkRange;

    let offsetX = width / 2 - (character.x - character.y) * tileSize;
    let offsetY = height / 3 - (character.x + character.y) * tileSize / 2;

    for (let cx = startX; cx <= endX; cx++) {
        for (let cy = startY; cy <= endY; cy++) {
            let chunkKey = `${cx},${cy}`;
            if (chunks[chunkKey]) {
                for (let i = 0; i < CHUNK_SIZE; i++) {
                    for (let j = 0; j < CHUNK_SIZE; j++) {
                        const tile = chunks[chunkKey][i][j];
                        if (tile.type === 0) { // Only draw for non-walkable tiles
                            const isoX = (cx * CHUNK_SIZE + i - cy * CHUNK_SIZE - j) * tileSize;
                            const isoY = (cx * CHUNK_SIZE + i + cy * CHUNK_SIZE + j) * tileSize / 2;
                            const screenX = offsetX + isoX;
                            const screenY = offsetY + isoY;

                            push();
                            translate(screenX, screenY - tileSize / 2);
                            applyMatrix(1, 0.5, -1, 0.5, 0, 0);
                            image(nonWalkableTileTexture, 0, 0, tileSize, tileSize);
                            pop();
                        }
                    }
                }
            }
        }
    }
}